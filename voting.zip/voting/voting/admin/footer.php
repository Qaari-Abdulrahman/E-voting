
<footer class="footer">
	<hr/>
&copy2023. Developed by Qaari.
<br/>
Online Voting System.
<br/>
Final Year Project 2018. Federal School of Surveying, Oyo
<br/>
Contact: <a href="tel:+2348083710341">+2348083710341</a> | Email: <a href="mailto:ollaabdulrahman6@gmail.com">ollaabdulrahman6@gmail.com</a>

</footer>
