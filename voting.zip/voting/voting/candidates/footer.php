
<footer class="footer">
	<hr/>
&copy2018. Developed by Qaari.
<br/>
Online Voting System.
<br/>
Final Year Project 2023. Federal School of Surveying, Oyo
<br/>
Contact: <a href="tel:+2348083710341">+2238083710341</a> | Email: <a href="mailto:ollaabdulrahman6@gmail.com">ollaabdulrahman6@gmail.com</a>

</footer>
