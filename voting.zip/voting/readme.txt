voting-System
"voting-System" Management System is designed for voting for any candidate online. Designed by using HTML / CSS / JS / PHP (procedural php) / MYSQL. 

Languages and Framworks HTML CSS JS PHP (procedural php) MYSQL


Admin Access Information

Logi ID: 1
Username: admin

Password: admin


User Access Information

Login ID: 4
Username: user
Password: user